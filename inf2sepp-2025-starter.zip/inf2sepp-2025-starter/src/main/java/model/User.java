package model;

public abstract class User {

}
