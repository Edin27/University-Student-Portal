package model;

public class Guest extends User {
}
